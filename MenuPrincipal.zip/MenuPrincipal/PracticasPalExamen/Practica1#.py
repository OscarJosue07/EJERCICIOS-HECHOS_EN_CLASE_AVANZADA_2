def mostrarmenu():
    print("\n" + "="*40)
    print("CONVERSOR DE TEMPERATURAS")
    print("="*40)
    print("1. Grados Celsius a Grados Fahrenheit")
    print("2. Grados Celsius a Kelvin")
    print("3. Grados Celsius a Rankine")
    print("4. Grados Fahrenheit a Grados Celsius")
    print("5. Grados Fahrenheit a Kelvin")
    print("6. Grados Fahrenheit a Rankine")
    print("7. Kelvin a Grados Celsius")
    print("8. Kelvin a Grados Fahrenheit")
    print("9. Salir")
    print("="*40)

def menuconversor():
    while True:
        mostrarmenu()
        opcion = input("Seleccione una opcion: ")

        if opcion == "9":
            print("\n Hasta luego ")
            break

        if opcion in ["1", "2", "3", "4", "5", "6", "7", "8"]:
            try:
                valor = float(input("Ingrese el valor de temperatura a convertir: "))
                
                if opcion == "1":
                    resultado = valor * 1.8 + 32
                    print(f"\nResultado: {valor} °C = {resultado:.2f} °F")
                
                elif opcion == "2":
                    resultado = valor + 273.15
                    print(f"\nResultado: {valor} °C = {resultado:.2f} K")
                
                elif opcion == "3":
                    resultado = (valor + 273.15) * 1.8
                    print(f"\nResultado: {valor} °C = {resultado:.2f} R")
                
                elif opcion == "4":
                    resultado = (valor - 32) / 1.8
                    print(f"\nResultado: {valor} °F = {resultado:.2f} °C")
                
                elif opcion == "5":
                    resultado = (valor + 459.67) / 1.8
                    print(f"\nResultado: {valor} °F = {resultado:.2f} K")
                
                elif opcion == "6":
                    resultado = valor + 459.67
                    print(f"\nResultado: {valor} °F = {resultado:.2f} R")
                
                elif opcion == "7":
                    resultado = valor - 273.15
                    print(f"\nResultado: {valor} K = {resultado:.2f} °C")
                
                elif opcion == "8":
                    resultado = (9 * valor) - 459.67
                    print(f"\nResultado: {valor} K = {resultado:.2f} °F")
            
            except ValueError:
                print("\nError: Por favor, ingrese un numero valido.")
        else:
            print("\nOpción no válida. Por favor, elija un numero del 1 al 9.")


menuconversor()
#ejercicos de clases con funciones con numpy con pandas