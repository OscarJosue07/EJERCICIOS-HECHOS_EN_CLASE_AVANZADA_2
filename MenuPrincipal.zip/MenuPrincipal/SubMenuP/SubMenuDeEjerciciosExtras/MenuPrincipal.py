
import os
import subprocess
import sys

directorio_actual = os.path.dirname(os.path.abspath(__file__))
ruta_submenu_clase = os.path.join(directorio_actual, "..", "SubMenuEjerciciosHechosEnClase", "SubMenuC.py")
ruta_submenu_extras = os.path.join(directorio_actual, "SubMenu.py")

continuar = True
while continuar:
    os.system('cls' if os.name == 'nt' else 'clear')
    print("\n=== MENU PRINCIPAL ===")
    print("1) Ejercicios hechos en clase")
    print("2) Ejercicios extra")
    print("3) Salir")
    
    opcion = input("Ingrese una opcion: ")
    
    if opcion == '1':
        subprocess.run([sys.executable, ruta_submenu_clase])
    elif opcion == '2':
        subprocess.run([sys.executable, ruta_submenu_extras])
    elif opcion == '3':
        continuar = False
        print("Saliendo del programa...")
    else:
        input("Opcion invalida. Presione Enter para continuar...")