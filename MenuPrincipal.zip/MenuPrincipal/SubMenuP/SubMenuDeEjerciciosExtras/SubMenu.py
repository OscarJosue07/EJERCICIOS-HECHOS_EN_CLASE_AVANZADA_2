import math

def mostrar_submenu_extra():
    continuar = True
    while continuar:
        print("""
        === Submenú Extra (Matematicas) ===
        1) Pitagoras         6) Factorial
        2) Area Circulo      7) Raiz Cuadrada
        3) Dist. 2 Puntos    8) Potencia
        4) Volumen Esfera    9) Convertir a Binario
        5) Par o Impar       10) Funcion Cuadratica
        0) Regresar
        """)
        try:
            opcion = int(input("Ingrese una opcion: "))
            
            match opcion:
                case 1:
                    a, b = float(input("Cateto A: ")), float(input("Cateto B: "))
                    print(f"Hipotenusa: {math.sqrt(a**2 + b**2)}")
                case 2:
                    r = float(input("Radio: "))
                    print(f"Área: {math.pi * r**2}")
                case 3:
                    x1, y1 = float(input("x1: ")), float(input("y1: "))
                    x2, y2 = float(input("x2: ")), float(input("y2: "))
                    print(f"Distancia: {math.sqrt((x2-x1)**2 + (y2-y1)**2)}")
                case 4:
                    r = float(input("Radio: "))
                    print(f"Volumen: {(4/3) * math.pi * r**3}")
                case 5:
                    n = int(input("Numero entero: "))
                    print("Es Par" if n % 2 == 0 else "Es Impar")
                case 6:
                    n = int(input("Numero entero: "))
                    print(f"Factorial: {math.factorial(n)}")
                case 7:
                    n = float(input("Numero: "))
                    print(f"Raiz: {math.sqrt(n)}" if n >= 0 else "Error: Numero negativo")
                case 8:
                    b, e = float(input("Base: ")), float(input("Exponente: "))
                    print(f"Resultado: {math.pow(b, e)}")
                case 9:
                    n = int(input("Numero entero: "))
                    print(f"Binario: {bin(n)[2:]}")
                case 10:
                    a = float(input("Coeficiente a: "))
                    b = float(input("Coeficiente b: "))
                    c = float(input("Coeficiente c: "))
                    x = float(input("Valor x: "))
                    print(f"f(x) = {a}*x^2 + {b}*x + {c} = {a*x**2 + b*x + c}")
                case 0:
                    continuar = False
                case _:
                    print("Opcion invalida")
        except ValueError:
            print("Error: Ingrese un numero valido")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    mostrar_submenu_extra()