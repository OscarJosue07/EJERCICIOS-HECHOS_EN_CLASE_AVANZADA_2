#programa que calcula el factorial que pida el numero y lo muestre

fac=float(input("Ingrese el numero: "))
if fac<0:
    print("El factorial no existe para numeros negativos")
elif fac==0:
    print("El factorial de 0 es 1")
else:
    factorial=1
    for i in range(1, int(fac)+1):
        factorial *= i
    print(f"El factorial de {int(fac)} es: {factorial}")