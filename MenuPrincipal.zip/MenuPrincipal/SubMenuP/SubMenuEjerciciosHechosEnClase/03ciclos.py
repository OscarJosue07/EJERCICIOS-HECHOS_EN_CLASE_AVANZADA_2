#ciclo for

for i in range(5):
    print (i)

for i in range(0,10,2):
    print (1)

cadena ="Oscar"
for index , Letra in enumerate(cadena):
    print (f"Indice: (index), letra: (letra)")


array = [1,2,3,4,5]

arrarftutas = ["manzana","banana","naranja"]
for item in arrarftutas:
    print(item)

