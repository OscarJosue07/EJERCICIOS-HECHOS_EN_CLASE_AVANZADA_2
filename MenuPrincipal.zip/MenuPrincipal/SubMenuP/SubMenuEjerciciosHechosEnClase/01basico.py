    # Tipo De Datos;

    # nombre = input("Cual es tu nombre: ")
    # print ("Hola "+ nombre)

    # print("Ecuaciones Lineales: ax + b = 0")
    # a=int(input("a: "));

    # if a == 0:
    #     print("No es una ecuacion lineal")
    # else:
    #     b=int(input("b: "))
    #     x=-b/a
    #     print("x:"+ str(x))
    #     print("x es tipo:"+ str(type(x)))

z = None

if z:
    print("z Verdadero:"+ str(z))

else:
    print("z Falso:"+ str(z))
    
print("z es tipo:"+ str(type(z)))




