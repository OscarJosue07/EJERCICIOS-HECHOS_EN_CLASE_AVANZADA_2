import math
class Cuadratica:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    def delta(self):
        return self.b ** 2 - 4 * self.a * self.c
    def raices(self):
        # para a=0 se convirte en ecuacion lineal
        if self.a == 0 and self.b>0:
            print("Es una ecuacion lineal")
            print(f"x={-self.c/self.b}")
        if self.c==0 and self.a>0:
            print("Es una ecuacion de segundo grado incompleta")
            print(f"x1=0\nx2={-self.b/self.a}")
        
        if self.a!=0 and self.c!=0:
            if self.delta() > 0:
                x1= (-self.b + self.delta()**0.5) / (2 * self.a)
                x2= (-self.b - self.delta()**0.5) / (2 * self.a)
                print(x1)
                print(x2)
            else:
                parte_real= -self.b/(2*self.a)
                partecompleja= (abs(self.delta())**0.5)/(2*self.a)
                print(f"x1={parte_real}+{partecompleja}i")
                print(f"x2={parte_real}-{partecompleja}i")