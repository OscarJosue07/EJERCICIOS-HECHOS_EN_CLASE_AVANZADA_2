#crear un arreglo de 4 calificaciones, calcular el promedio

Notas = [0,0,0,0]

for i in range(4):
    nota = float(input("Nota: " + str(i+1) + " "))

    if nota == 0:
        print("No puede ser cero, vuelva a ingresar la nota")
        nota = float(input("Nota: " + str(i+1) + " "))

    Notas[i] = nota

promedio = sum(Notas) / 4
print("El promedio es:", promedio)

