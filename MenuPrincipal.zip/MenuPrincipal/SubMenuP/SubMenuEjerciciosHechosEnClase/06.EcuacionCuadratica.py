#un programa que de las solucines complejas y no reales
# ax2+bx+c=0
# delta= b2-4ac
#x= -b+-raizdelta/2a

import os

print(f"Solucion Cuadratica")
os.system("cls")
a=float(input("Ingrese a: "))
b=float(input("Ingrese b: "))
c=float(input("Ingrese c: "))

des=b**2-4*a*c

if a == 0:
    print("No es una ecuacion cuadratica")



if des>0:
    x1=(-b+des**0.5)/(2*a)
    x2=(-b-des**0.5)/(2*a)
    print(f"El valor de x1 es: {x1}\n El valor de x2 es: {x2}")

if des<0:
    partereal=-b/(2*a)
    partecompleja=(abs(des)**0.5)/(2*a)
    print(f"x={partereal} + {partecompleja}i")
    print(f"x={partereal} - {partecompleja}i")
 