import cmath

print("-- Resolucion de ecuacion cubica -- (ax^3 + bx^2 + cx + d = 0) ---")

a = float (input("Ingrese el coeficiente de a: "))
b = float (input("Ingrese el coeficiente de b: "))
c = float (input("Ingrese el coeficiente de c: "))
d = float (input("Ingrese el coeficiente de d: "))

if a == 0:
        print("El coeficiente de a no puede ser 0 en una ecuacion cubica")
else:
        p = (3 * a * c - b**2) / (3 * a**2)
        q = (2 * b**3 - 9 * a * b * c + 27 * a**2 *d) / (27 * a**3)

        discriminante = ( q**2 / 4) + ( p**3 / 27)

        u3 = -q / 2 + cmath.sqrt(discriminante)
        v3 = -q / 2 - cmath.sqrt(discriminante)

        u = u3 ** (1/3) if u3.real >= 0 else -(-u3) ** (1/3)

        u = cmath.exp(cmath.log(u3) / 3)
        v = cmath.exp(cmath.log(v3) / 3)

        w1 = 1
        w2 = complex (-0.5, cmath.sqrt(3)/2)
        w3 = complex (-0.5, -cmath.sqrt(3)/2)

        x1 = u + v - (b / (3 * a))
        x2 = (u * w2) + (v * w3) - (b / (3 * a))
        x3 = (u * w3) + (v * w2) - (b / (3 * a))

        print(f"x1 = {x1.real:.4f}" if abs(x1.imag) < 1e-9 else f"x1 = {x1:.4f}")
        print(f"x2 = {x2.real:.4f}" if abs(x2.imag) < 1e-9 else f"x2 = {x2:.4f}")
        print(f"x3 = {x3.real:.4f}" if abs(x3.imag) < 1e-9 else f"x3 = {x3:.4f}")