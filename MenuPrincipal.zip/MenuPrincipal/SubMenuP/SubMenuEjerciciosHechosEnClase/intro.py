import pandas as pd
from array import array

edades = array('i',[18,19,20,18])

estudiantes = ["Carlos","Maria","Jose","Ana"]

notas = {"Carlos": 85,
         "Maria": 90,
         "Jose": 75,
         "Ana": 95
         }
         
print("LISTA DE ESTUDIANTES")
print(estudiantes)

print("\nDICCIONARIO DE NOTAS")
print(notas)

print("\nARREGLO DE EDADES")
print(edades)

print("\nRECORRIDO DE DATOS")
for i in range(len(estudiantes)):
    nombre = estudiantes[i]
    nota = notas[nombre]
    edad = edades[i]

    print(f"Estudiantes: {nombre} | Edad: {edad} | Nota: {nota}")

print("\nAGREGANDO UN NUEVO ESTUDIANTE")

estudiantes.append("Pedro")
notas["Pedro"] = 88
edades.append(21)

print(f"Estudiante: {nombre} | Edad: {edad} | Nota: {nota}")

pandas_df = pd.DataFrame({
  "Nota": notas.values()
})

print("\nDATAFRAME SOLO CON NOTAS")
print(pandas_df)

