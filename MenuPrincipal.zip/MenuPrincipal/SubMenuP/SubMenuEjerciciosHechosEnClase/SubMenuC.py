import os
import subprocess
import sys

def mostrar_submenu_clase():
    directorio_actual = os.path.dirname(os.path.abspath(__file__))
    
    continuar = True
    while continuar:
        print("""
        === Submenu Clases ===
        1) Básico
        2) Ejercicios
        3) Ciclos
        4) Calificaciones
        5) Factorial
        0) Regresar
        """)
        opcion = int(input("Ingrese una opcion: "))
        
        match opcion:
            case 1:
                subprocess.run([sys.executable, os.path.join(directorio_actual, "01basico.py")])
            case 2:
                subprocess.run([sys.executable, os.path.join(directorio_actual, "02ejercicios.py")])
            case 3:
                subprocess.run([sys.executable, os.path.join(directorio_actual, "03ciclos.py")])
            case 4:
                subprocess.run([sys.executable, os.path.join(directorio_actual, "04Calificaciones.py")])
            case 5:
                subprocess.run([sys.executable, os.path.join(directorio_actual, "05Factorial.py")])
            case 0:
                continuar = False
            case _:
                print("Opcion invalida")

if __name__ == "__main__":
    mostrar_submenu_clase()