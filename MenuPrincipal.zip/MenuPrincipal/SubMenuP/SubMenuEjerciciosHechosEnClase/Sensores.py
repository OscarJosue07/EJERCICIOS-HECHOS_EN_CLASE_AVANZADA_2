sen1=True
sen2=True
sen3=False
sen4=True
sensores=[sen1, sen2, sen3, sen4]
contador=0

for i in sensores:
    if i==True and contador==1:
        print(f"Sensor 1 esta encendido: {sen1}")
        contador+=1
    elif i==True and contador==2:
        print(f"Sensor 2 esta encendido: {sen2}")
        contador+=1
    elif i==True and contador==3:
        print(f"Sensor 3 esta encendido: {sen3}")
        contador+=1
    elif i==True and contador==4:
        print(f"Sensor 4 esta encendido: {sen4}")
        contador+=1

print(f"Cantidad de sensores encendidos: {contador}")

if contador==0:
    print("No hay sensores")
elif contador==1:
    print("Fallo Leve")
elif contador==2:
    print("Falla Inderminada")
elif contador==3:
    print("Falle 3")
elif contador==4:
    print("Fallo Grave")


   